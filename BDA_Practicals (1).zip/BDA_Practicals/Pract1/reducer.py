#!/usr/bin/env python3  
import sys  

current_word = None  
current_count = 0  

# Input comes from standard input  
for line in sys.stdin:  
    word, count = line.strip().split('\t')  
    
    try:  
        count = int(count)  
    except ValueError:  
        continue  
        
    if current_word == word:  
        current_count += count  
    else:  
        if current_word:  
            print(f'{current_word}\t{current_count}')  
        current_word = word  
        current_count = count  
 
# Output the last word  
if current_word:  
    print(f'{current_word}\t{current_count}')